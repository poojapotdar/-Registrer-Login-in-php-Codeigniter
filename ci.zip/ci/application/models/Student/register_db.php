<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Register_db extends CI_Model{
	
	public function __construct()
	{
		parent :: __construct();
	}
	public function insert_data()
	{
		$data=array(
		'firstName'=>$this->input->post('firstName'),
		'lastName'=>$this->input->post('lastName'),
		'email'=>$this->input->post('email'),
		'password'=>$this->input->post('password'),
		'com_password'=>$this->input->post('com_password'),
		'birthDate'=>$this->input->post('birthDate'),
		'phoneNumber'=>$this->input->post('phoneNumber'),
		'height'=>$this->input->post('height'),
		'weight'=>$this->input->post('weight'),
		'gender'=>$this->input->post('gender')
		);
		$register_data=$this->db->insert('register',$data);
	}
	
}
 
?>