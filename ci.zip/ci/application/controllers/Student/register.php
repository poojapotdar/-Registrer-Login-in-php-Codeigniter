<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller
{
	
	public function index()
	{
		$this->load->view('Student/register');
	}
	public function store()
	{
		$this->load->model('Student/register_db');
		$r=new register_db();
		$r->insert_data();
		redirect(base_url('message'));
	}
}
?>